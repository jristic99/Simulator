#include "DigitalCircuit.h"

bool DigitalCircuit::findProbeOutput(const vector<Element*> &elements_, Element* probe, double time) const
{
	Element* current = probe;
	stack<Element*> unvisited = {}; // Stack elemenata koje treba posetiti
	set<Element*> visited = {}; // Skup elemenata koji su vec poseceni, i za koje se zna output u trenutku time

	unvisited.push(current); // Stavljamo sondu na stack
	while (!unvisited.empty()) // Sve dok postoji neposecen element, obradjujemo elemente
	{
		current = unvisited.top(); // Uzimamo prvi element sa steka

		if (current->isGenerator()) // Ukoliko je generator, znamo da mu izracunamo output
		{
			current->calculateOutput(time);
			unvisited.pop(); // Skidamo sa steka
			visited.insert(current); // Stavljamo u posecene
		}
		else
		{
			bool allChildrenVisited = true; // Ako nije generator, posmataramo mu ulaze
			for (int i = 0; i < current->getNumPins(); i++)
			{
				if (visited.find(current->getChild(i)) == visited.end()) 
				{
					// Ukoliko postoji dete koje nije poseceno, stavljamo ga na stek
					unvisited.push(current->getChild(i));
					allChildrenVisited = false;
				}
			}
			if (allChildrenVisited) // Ukoliko su sva deca vec posecena, znaci da mozemo izracunati output 
			{
				current->calculateOutput(time);
				unvisited.pop(); // Skidamo sa steka
				visited.insert(current); // Stavljamo u posecene
			}
		}
	}
	return probe->getOutput(time); // Vracamo vrednost izlaza 
}
