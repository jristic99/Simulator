#ifndef SIMULATOR_H
#define SIMULATOR_H

#include "DigitalCircuit.h"
#include "Element.h"
#include "Reader.h"
#include "Writter.h"
#include "Exceptions.h"
#include <algorithm>
#include <iostream>
#include <cmath>

using namespace std;

class Simulator
{
public:
	Simulator();
	~Simulator();

	Simulator(const Simulator&) = delete; // Zabranjujemo kopirajuci konstruktor
	Simulator(const Simulator&&) = delete; // Zabranjujemo premestajuci konstruktor

	void loadCircuit(const string& filepath); // Ucitava digitalno kolo
	void simulate(const string& filepath); // Simulira rad kola

private:
	double sim_time_; // Duzina trajanja simulacije
	int num_elements_; // Broj elemenata u kolu
	Reader* reader_; // Objekat zaduzen za citanje
	Writter* writter_; // Objekat zaduzen za pisanje
	DigitalCircuit* digital_circuit_; // Objekat zaduzen za obilaz drveta i izracunavanje izlaza na sondama
	vector<double> simulation_time_; // Vektor trenutaka promena u kolu
	vector<Element*> elements_; // Vektor povezanih elemenata
	vector<Element*> probes_; // Vektor pokazivaca na sonde
	vector<Element*> generators_; // Vektor pokazivaca na generatore
	vector<vector<bool>> probes_output_; // Matrica koja sadrzi izlaz u svakom trenutku promene za svaku sondu

	vector<Element*> getProbes(); // Vraca pokazivace na sve sonde
	vector<Element*> getGenerators(); // Vraca pokazivace na sve generatore

	void findChangingMoments(); // Azurira vektor simulation_time_
	void deletePrevious(); // Brise podatke o prethodnom kolu
};


#endif