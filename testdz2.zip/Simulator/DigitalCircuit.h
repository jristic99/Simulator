#ifndef DIGITAL_CIRCUIT_H
#define DIGITAL_CIRCUIT_H

#include "Element.h"
#include <stack>
#include <set>

class DigitalCircuit
{
public:
	bool findProbeOutput(const vector<Element*> &elements_, Element* probe, double time) const;
	// Klasa zaduzena za obilazak drveta u racunanje vrednosti
	// Zbog raspodele odgovornosti, ova funkcija koja nalazi vrednost sonde probe u trenutku time, izdvojena
	// je u posebnu klasu. Ovakva struktura pogodna je za potencijalna prosirenja
};

#endif