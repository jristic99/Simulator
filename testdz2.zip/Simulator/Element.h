#ifndef ELEMENT_H
#define ELEMENT_H

#include "Exceptions.h"
#include <vector>
using namespace std;

class Element // Apstraktna klasa
{
public:
	Element(int id);
	virtual ~Element(); // Virtuelni desktruktor radi propisnog unistavanja objekata nasledjenih klasa

	Element(const Element& other); // Kopirajuci konstruktor
	Element(const Element&& other); // Premestajuci konstruktor
	
	virtual Element* clone() const = 0; // Fukncija koja omogucava propisnu kopiju objekta nasledjenih klasa

	virtual int getNumPins() const = 0; // Funkcija koja vraca broj ulaza u element
	int getId() const; // Funkcija koja vraca identifikator elementa
	Element* getChild(int pin) const;

	void setChild(Element* child, int pin);
	// Funkcija koja postavlja postavlja element child kao ulaz u element this i na ulaz oznacen int-om pin

	virtual bool isGenerator() const; // Da li je element generator
	virtual bool isProbe() const; // Da li je element sonda

	virtual vector<double> getChangingMoments(double final_moment); 
	// Vraca sve trenutke u kojima se desava promena na bilo kom generatoru
	virtual bool calculateOutput(double time) = 0; // Racuna output na osnovu ulaza
	virtual bool getOutput(double time); // Vraca izracunati output

protected:
	vector<Element*> children_; // Vektor pointer-a na elemente, koji predstavljaju ulaz u element this
	bool output_; // Izlazna vrednost

private:
	int id_; // Identifikator
};

class DigitalSource : public Element // Apstraktna klasa, ne postoje objekti ove klase
{
public:
	virtual int getNumPins() const override;
	virtual bool isGenerator() const override;

protected: // Konstruktori ove klase treba da budu vidljivi samo nasledjenim klasama
	DigitalSource(int id);
	DigitalSource(const DigitalSource& other);
	DigitalSource(const DigitalSource&& other);
};


class ClockSignal : public DigitalSource
{
public:
	ClockSignal(int id, double frequency);

	ClockSignal(const ClockSignal& other);
	ClockSignal(const ClockSignal&& other);

	virtual ClockSignal* clone() const override;

	virtual vector<double> getChangingMoments(double final_moment) override;
	virtual bool calculateOutput(double time) override;
private:
	double frequency_;
};

class ManualSignal : public DigitalSource
{
public:
	ManualSignal(int id, vector<double> changes);

	ManualSignal(const ManualSignal& other);
	ManualSignal(const ManualSignal&& other);

	virtual ManualSignal* clone() const override;

	virtual vector<double> getChangingMoments(double final_moment) override;
	virtual bool calculateOutput(double time) override;

private:
	vector<double> changes_; // Vektor relativnih trenutaka promena izlaza rucnog izvora
};

class LogicCircuit : public Element // Apstraktna klasa, ne postoje objekti ove klase
{
public:
	virtual int getNumPins() const override;

protected: // Konstruktori ove klase treba da budu vidljivi samo nasledjenim klasama
	LogicCircuit(int id, int num_pins);

	LogicCircuit(const LogicCircuit& other);
	LogicCircuit(const LogicCircuit&& other);

private:
	int num_pins_;
};

class NotCircuit : public LogicCircuit
{
public:
	NotCircuit(int id);

	NotCircuit(const NotCircuit& other);
	NotCircuit(const NotCircuit&& other);

	virtual NotCircuit* clone() const override;

	virtual bool calculateOutput(double time) override;
};

class AndCircuit : public LogicCircuit
{
public:
	AndCircuit(int id, int num_pins);

	AndCircuit(const AndCircuit& other);
	AndCircuit(const AndCircuit&& other);

	virtual AndCircuit* clone() const override;

	virtual bool calculateOutput(double time) override;
};

class OrCircuit : public LogicCircuit
{
public:
	OrCircuit(int id, int num_pins);

	OrCircuit(const OrCircuit& other);
	OrCircuit(const OrCircuit&& other);

	virtual OrCircuit* clone() const override;

	virtual bool calculateOutput(double time) override;
};

class Probe : public Element
{
public:
	Probe(int id);

	Probe(const Probe& other);
	Probe(const Probe&& other);

	virtual Probe* clone() const override;

	virtual int getNumPins() const override;
	virtual bool isProbe() const override;
	virtual bool calculateOutput(double time) override;

};

#endif