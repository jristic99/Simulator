#include "Element.h"

Element::Element(int id) : id_(id) {}

Element::~Element() {} // nema dinamicki alocirane memorije

Element::Element(const Element & other) 
// Kopirajuci konstruktor kopira tip elementa i njegov id, a ulaze postavlja na nullptr
{
	id_ = other.id_;
}

Element::Element(const Element && other)
{
	id_ = other.id_;

	for (auto child : other.children_) // Kopiramo pokazivace na input
		children_.push_back(child);

	for (auto child : other.children_) // Postavljamo pokazivace other-a na nullptr
		child = nullptr;
}

int Element::getId() const
{
	return id_;
}

Element * Element::getChild(int pin) const
{
	return children_[pin];
}

bool Element::isGenerator() const 
// Vraca false u osnovnoj klasni, a override-uje je samo klasa DigitalSource
{
	return false;
}

bool Element::isProbe() const
{
	return false;
}

vector<double> Element::getChangingMoments(double final_moment)
// Vraca prazan skup u osnovnoj klasi, a override-uje je klasa DigitalSource
{
	return {};
}

void Element::setChild(Element* child, int pin)
{
	if(pin < getNumPins()) // Ukoliko je pin izvan ocekivanih vrednosti, vratiti izuzetak
		children_[pin] = child;
	else throw WrongPin("Pin value::out of range");
}

bool Element::getOutput(double time)
{
	return output_;
}

DigitalSource::DigitalSource(int id) : Element(id) {}

DigitalSource::DigitalSource(const DigitalSource& other) : Element(other) {}

DigitalSource::DigitalSource(const DigitalSource && other) : Element(other) {}

int DigitalSource::getNumPins() const
{
	return 0;
}

bool DigitalSource::isGenerator() const
{
	return true;
}

Probe::Probe(int id) : Element(id) 
{
	// Stavljamo u vektor jedan nullptr, jer sonda ima tacno jedan ulaz
	children_.push_back(nullptr);
}

Probe::Probe(const Probe& other) : Element(other) {}

Probe::Probe(const Probe && other) : Element(other) {}

Probe* Probe::clone() const
{
	return new Probe(*this);
}

int Probe::getNumPins() const
{
	return 1;
}

bool Probe::isProbe() const
{
	return true;
}

bool Probe::calculateOutput(double time) // racuna izlaz, pamti u polje klase, i vraca tu vrednost
{
	output_ = (children_[0])->getOutput(time);
	return output_;
}

ClockSignal::ClockSignal(int id, double frequency) : 
	DigitalSource(id), frequency_(frequency) {}

ClockSignal::ClockSignal(const ClockSignal& other) : DigitalSource(other)
{
	frequency_ = other.frequency_;
}

ClockSignal::ClockSignal(const ClockSignal && other) : DigitalSource(other) 
{
	frequency_ = other.frequency_;
}

ClockSignal* ClockSignal::clone() const
{
	return new ClockSignal(*this);
}

vector<double> ClockSignal::getChangingMoments(double final_moment)
{
	vector<double> changes = {};
	double curr_moment = 0;
	double half_period = 1 / frequency_ / 2;

	// Stavljamo u vektor sve trenutke promene vrednosti izlaza CLOCK signala, sto je na polovini svake periode
	while (curr_moment < final_moment) 
	// Trazimo sve trenutke koji se desavaju pre trenutka final_moment, sto ce biti kraj simulacije
	{
		changes.push_back(curr_moment);
		curr_moment += half_period;
	}
	return changes;
}

bool ClockSignal::calculateOutput(double time)
{
	bool output = false;
	double time_tmp = time;
	double period = 1 / frequency_;
	while (time_tmp - period >= 0) time_tmp -= period; 
	// Oduzimamo ceo broj perioda, dok ne dobijemo broj manji od periode

    // Kada je trenutak jednak celom broju periode, CLOCK vraca false
	if ((abs(time_tmp - period) < pow(10, -6)))
	{
		output_ = false;
		return false;
	} // Ova provera dodata je zbog slucaja kada su trenuci tipa double. Dve double vrednosti koje matematicki
	  // imaju isti vrednost, se mogu razlikovati na nekoj dalekoj decimali kada su zapisane u racunaru. Zbog toga
	  // proveravamo da li je njihova razlika manja od nekog jako malog broja (sto znaci da su efektivno jednake).

	// Ukoliko je trenutak veci ili jednak poluperiodi, CLOCK vracam true, a u suprotnom false
	if((abs(time_tmp - period / 2) < pow(10, -6)) || time_tmp > period / 2)
		output = true;
	else output = false;

	// Pamtimo izlaz, i vracamo
	output_ = output;
	return output;
}

ManualSignal::ManualSignal(int id, vector<double> changes) : 
	DigitalSource(id), changes_(changes) {}

ManualSignal::ManualSignal(const ManualSignal & other) : DigitalSource(other)
// Pored id-a, kopira se i niz promena
{
	changes_ = other.changes_;
}

ManualSignal::ManualSignal(const ManualSignal && other) : DigitalSource(other)
{
	changes_ = other.changes_;
}

ManualSignal* ManualSignal::clone() const
{
	return new ManualSignal(*this);
}

vector<double> ManualSignal::getChangingMoments(double final_moment)
{
	double current = 0;
	int i;
	// Ukoliko zbir relativnih trenutaka prelazi duzinu trajanja simulacije, zanemaruju se trenuci posle toga
	for (i = 0; i < changes_.size(); i++)
		if(current + changes_[i] < final_moment)
		{
			current += changes_[i];
			changes_[i] = current;
		}
		else break;
	changes_.resize(i);
	return changes_;
}

bool ManualSignal::calculateOutput(double time)
{
	bool output = false;
	// Za svaki trenutak promene, ukoliko je manji od posmatranog trenutka time, menjamo vrednost output
	for (int i = 0; i < changes_.size(); i++)
		if (changes_[i] <= time) output = !output;
		else break;
	output_ = output;
	return output;
}

LogicCircuit::LogicCircuit(int id, int num_pins) : 
	Element(id), num_pins_(num_pins)
{
	if (num_pins > 0)
		children_.assign(num_pins, nullptr); 
	    // Pravimo vektor duzine num_pins, sa nullptr-ima
}

LogicCircuit::LogicCircuit(const LogicCircuit & other) : Element(other)
{
	children_.assign(other.num_pins_, nullptr); // Pravimo vektor duzine num_pins, sa nullptr-ima
}

LogicCircuit::LogicCircuit(const LogicCircuit && other) : Element(other) {}

int LogicCircuit::getNumPins() const
{
	return num_pins_;
}

NotCircuit::NotCircuit(int id) : LogicCircuit(id, 1) {}

NotCircuit* NotCircuit::clone() const
{
	return new NotCircuit(*this);
}

NotCircuit::NotCircuit(const NotCircuit & other) : LogicCircuit(other) {}

NotCircuit::NotCircuit(const NotCircuit && other) : LogicCircuit(other) {}

bool NotCircuit::calculateOutput(double time) // Racuna output na osnovu ulaza
{
	output_ = !(children_[0]->getOutput(time));
	return output_;
}

AndCircuit::AndCircuit(int id, int num_pins) : LogicCircuit(id, num_pins) {}

AndCircuit::AndCircuit(const AndCircuit & other) : LogicCircuit(other) {}

AndCircuit::AndCircuit(const AndCircuit && other) : LogicCircuit(other) {}

AndCircuit * AndCircuit::clone() const
{
	return new AndCircuit(*this);
}

bool AndCircuit::calculateOutput(double time)
{
	bool output = true;
	for (auto child : children_) // Racuna logicko I nad svim ulazima
		output = output && child->getOutput(time);
	output_ = output;
	return output;
}

OrCircuit::OrCircuit(int id, int num_pins) : LogicCircuit(id, num_pins) {}

OrCircuit::OrCircuit(const OrCircuit & other) : LogicCircuit(other) {}

OrCircuit::OrCircuit(const OrCircuit && other) : LogicCircuit(other) {}

OrCircuit* OrCircuit::clone() const
{
	return new OrCircuit(*this);
}

bool OrCircuit::calculateOutput(double time) // Racuna logicko ILI nad svim ulazima
{
	bool output = false;
	for (auto child : children_)
		output = output || child->getOutput(time);
	output_ = output;
	return output;
}
