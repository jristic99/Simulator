#include "Simulator.h"

void test();

int main()
{
	test();
	return 0;
}